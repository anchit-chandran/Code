input_string = """tis but our fantasy, and will not let belief take hold of him \n\ttouching this dreaded sight, twice seen of us.\n\t\tTherefore, I have entreated him along,\n\twith us to watch the minutes of this night, that, if again\nthis apparition come,\n\nHe may approve our eyes and speak to it"""

print(input_string)