""""
Write a function x(n) for computing an element in the sequence xn=n2+1. Call the
function for n=4 and print out the result to the console.
"""

def get_el_from_seq(n:int):
    
    return 1 + n**2

def solution_2():
    
    return get_el_from_seq(n=4)

print(solution_2())